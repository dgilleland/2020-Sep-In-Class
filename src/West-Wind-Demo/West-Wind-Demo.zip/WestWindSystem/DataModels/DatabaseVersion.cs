﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WestWindSystem.DataModels
{
    public class DatabaseVersion
    {
        public Version Version { get; set; }
        public DateTime ReleaseDate { get; set; }
    }
}
