﻿namespace WestWindSystem.DataModels
{
    public class ProductSummary // A simple POCO class
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Quantity { get; set; }
    }
}
